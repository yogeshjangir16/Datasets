# Sanskrit OCR > 2023-07-17 10:28pm
https://universe.roboflow.com/iitbresearchwork/sanskrit-ocr

Provided by a Roboflow user
License: CC BY 4.0

